# QA SDET Playwright

Automation for cPanel Store using Playwright.