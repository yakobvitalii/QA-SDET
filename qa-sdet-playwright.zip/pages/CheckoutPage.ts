import { Page } from '@playwright/test';

export class CheckoutPage {
    private page: Page;
    constructor(page: Page) {
        this.page = page;
    }

    async verifyCheckoutElements() {
        await this.page.waitForSelector('text=Personal Information');
        await this.page.waitForSelector('text=Billing Address');
        await this.page.waitForSelector('text=Payment Details');
        await this.page.waitForSelector('text=Complete Order');
    }

    async verifyCompleteOrderButtonDisabled() {
        return await this.page.locator('text=Complete Order').isDisabled();
    }
}
