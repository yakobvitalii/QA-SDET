import { Page } from '@playwright/test';

export class CartPage {
    private page: Page;
    constructor(page: Page) {
        this.page = page;
    }

    async verifyOrderSummary() {
        return await this.page.locator('.order-summary').isVisible();
    }

    async proceedToCheckout() {
        await this.page.locator('text=Checkout').click();
    }
}
