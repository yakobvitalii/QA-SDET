import { Page } from '@playwright/test';

export class ProductPage {
    private page: Page;
    constructor(page: Page) {
        this.page = page;
    }

    async enterIPAddress(ip: string) {
        await this.page.fill('input[name="ip"]', ip);
    }

    async selectAddon() {
        await this.page.locator('input[type="checkbox"]').first().check();
    }

    async continueToCheckout() {
        await this.page.locator('text=Continue').click();
    }
}
