import { Page } from '@playwright/test';

export class HomePage {
    private page: Page;
    constructor(page: Page) {
        this.page = page;
    }

    async navigate() {
        await this.page.goto('https://store.cpanel.net');
    }

    async orderProduct() {
        await this.page.locator('text=Order Now').first().click();
    }
}
