import { test, expect } from '@playwright/test';
import { HomePage } from '../pages/HomePage';
import { ProductPage } from '../pages/ProductPage';
import { CartPage } from '../pages/CartPage';
import { CheckoutPage } from '../pages/CheckoutPage';

test('Automate adding a product and addon to cart', async ({ page }) => {
    const homePage = new HomePage(page);
    const productPage = new ProductPage(page);
    const cartPage = new CartPage(page);
    const checkoutPage = new CheckoutPage(page);

    // 1. Перейти на сторінку магазину
    await homePage.navigate();

    // 2. Натиснути "Order Now"
    await homePage.orderProduct();

    // 3. Ввести IP-адресу
    await productPage.enterIPAddress('2.2.2.2');

    // 4. Вибрати аддон
    await productPage.selectAddon();

    // 5. Натиснути "Continue"
    await productPage.continueToCheckout();

    // 6. Перевірити, що Order Summary оновлений
    expect(await cartPage.verifyOrderSummary()).toBeTruthy();

    // 7. Перейти до чекауту
    await cartPage.proceedToCheckout();

    // 8. Перевірити наявність обов'язкових полів на сторінці чекауту
    await checkoutPage.verifyCheckoutElements();

    // 9. Переконатися, що кнопка "Complete Order" відключена
    expect(await checkoutPage.verifyCompleteOrderButtonDisabled()).toBeTruthy();
});
